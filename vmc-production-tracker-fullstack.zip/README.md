# VMC Production Tracker (Full-stack)

A production-recording application with React/Vite frontend, Express API, MongoDB, JWT admin login and ExcelJS export.

## Requirements
- Node.js 20+
- MongoDB Atlas database (or local MongoDB)
- npm

## 1. Configure backend
```bash
cd server
cp .env.example .env
npm install
```
Edit `.env`:
- `MONGODB_URI`: your MongoDB connection string
- `JWT_SECRET`: a long random secret (never commit this)
- `ADMIN_USERNAME` / `ADMIN_PASSWORD`: initial admin credentials
- `CLIENT_ORIGIN`: frontend URL, e.g. `http://localhost:5173`

Start:
```bash
npm run dev
```
On first start, the server creates the initial admin account if it does not exist.

## 2. Configure frontend
In another terminal:
```bash
cd client
cp .env.example .env
npm install
npm run dev
```
Open http://localhost:5173

## Features
- Admin login
- Production group structure: Date > Machine > Employee > Shift > Jobs
- Dynamic machine/employee/part autocomplete based on saved records; no preconfigured machine list or machine configuration page
- Add multiple jobs to one group
- Production history with search/filter, edit and delete
- Dashboard totals based on stored records
- Excel export (all or filtered records) with merged group-level Date, Machine, Employee and Shift cells
- Responsive layout

## Production deployment
1. Create MongoDB Atlas database and allow network access from your backend host. Prefer the host's static outbound IP allowlist when available; avoid `0.0.0.0/0` if possible.
2. Deploy `server` as a Node web service (Render or equivalent). Set the environment variables from `.env.example`. Set `CLIENT_ORIGIN` to your deployed frontend URL.
3. Deploy `client` as a static site (Vercel or equivalent). Set `VITE_API_URL` to the deployed backend URL plus `/api`, e.g. `https://your-api.onrender.com/api`.
4. Set `CLIENT_ORIGIN` on the backend to the exact frontend origin, e.g. `https://your-app.vercel.app`.
5. Change the initial admin password immediately after first login (or change `ADMIN_PASSWORD` before first deployment). Use a unique `JWT_SECRET`.
6. Test login, create/edit/delete, suggestions and Excel export.

## Important
This is a starter implementation. Before using it for critical factory operations, add automated tests, audit logs, backups, role-based access, rate limiting, monitoring and a documented recovery process. Do not use it to control CNC machinery; it is a record-keeping application.
