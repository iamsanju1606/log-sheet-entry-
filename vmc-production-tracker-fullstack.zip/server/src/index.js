import 'dotenv/config';
import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import ExcelJS from 'exceljs';
import { Production, Admin } from './models.js';
import { requireAuth } from './auth.js';

const app = express();
app.use(helmet());
app.use(cors({ origin: process.env.CLIENT_ORIGIN?.split(',') || 'http://localhost:5173' }));
app.use(express.json({ limit: '1mb' }));
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, limit: 30 }));

const clean = v => String(v ?? '').trim();
const validDate = v => !Number.isNaN(new Date(v).getTime());
const validatePayload = body => {
  const { date, machine, employee, shift, jobs } = body || {};
  if (!validDate(date) || !clean(machine) || !clean(employee) || !clean(shift) || !Array.isArray(jobs) || jobs.length < 1)
    return 'Date, machine, employee, shift and at least one job are required.';
  for (const j of jobs) {
    if (!clean(j.partDescription) || !clean(j.partNumber) || !clean(j.startTime) || !clean(j.endTime))
      return 'Each job needs part description, part number, start time and end time.';
    if (!/^([01]\\d|2[0-3]):[0-5]\\d$/.test(j.startTime) || !/^([01]\\d|2[0-3]):[0-5]\\d$/.test(j.endTime))
      return 'Time must be in HH:MM format.';
    if (!Number.isFinite(Number(j.okQty)) || Number(j.okQty) < 0) return 'OK Qty must be a non-negative number.';
  }
  return null;
};
const normalize = body => ({
  date: new Date(body.date), machine: clean(body.machine), employee: clean(body.employee), shift: clean(body.shift),
  jobs: body.jobs.map(j => ({
    partDescription: clean(j.partDescription), partNumber: clean(j.partNumber),
    startTime: clean(j.startTime), endTime: clean(j.endTime), okQty: Number(j.okQty),
    operation: clean(j.operation), otherRemark: clean(j.otherRemark)
  }))
});

app.get('/api/health', (_req, res) => res.json({ ok: true }));

app.post('/api/auth/login', async (req, res) => {
  const username = clean(req.body?.username);
  const admin = await Admin.findOne({ username });
  if (!admin || !(await bcrypt.compare(String(req.body?.password || ''), admin.passwordHash)))
    return res.status(401).json({ message: 'Invalid username or password' });
  const token = jwt.sign({ sub: admin._id.toString(), username }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '12h' });
  res.json({ token, username });
});

app.use('/api', requireAuth);

app.get('/api/dashboard', async (_req, res) => {
  const rows = await Production.find().lean();
  const jobs = rows.flatMap(r => r.jobs || []);
  res.json({
    groups: rows.length,
    jobs: jobs.length,
    okQty: jobs.reduce((sum, j) => sum + Number(j.okQty || 0), 0),
    dates: new Set(rows.map(r => new Date(r.date).toISOString().slice(0,10))).size,
    machines: new Set(rows.map(r => r.machine.toLowerCase())).size,
    employees: new Set(rows.map(r => r.employee.toLowerCase())).size,
    recent: rows.sort((a,b) => new Date(b.date)-new Date(a.date)).slice(0,8)
  });
});

app.get('/api/productions', async (req, res) => {
  const q = {};
  if (req.query.from || req.query.to) {
    q.date = {};
    if (req.query.from) q.date.$gte = new Date(req.query.from);
    if (req.query.to) { const end = new Date(req.query.to); end.setHours(23,59,59,999); q.date.$lte = end; }
  }
  if (req.query.machine) q.machine = { $regex: String(req.query.machine), $options: 'i' };
  if (req.query.employee) q.employee = { $regex: String(req.query.employee), $options: 'i' };
  if (req.query.shift) q.shift = req.query.shift;
  const rows = await Production.find(q).sort({ date: -1, machine: 1, employee: 1 }).lean();
  const term = clean(req.query.search).toLowerCase();
  const filtered = term ? rows.filter(r => [r.machine,r.employee,r.shift,...r.jobs.flatMap(j => [j.partDescription,j.partNumber,j.operation,j.otherRemark])].join(' ').toLowerCase().includes(term)) : rows;
  res.json(filtered);
});

app.post('/api/productions', async (req, res) => {
  const error = validatePayload(req.body);
  if (error) return res.status(400).json({ message: error });
  const doc = await Production.create(normalize(req.body));
  res.status(201).json(doc);
});

app.put('/api/productions/:id', async (req, res) => {
  const error = validatePayload(req.body);
  if (error) return res.status(400).json({ message: error });
  const doc = await Production.findByIdAndUpdate(req.params.id, normalize(req.body), { new: true, runValidators: true });
  if (!doc) return res.status(404).json({ message: 'Production group not found' });
  res.json(doc);
});

app.delete('/api/productions/:id', async (req, res) => {
  const doc = await Production.findByIdAndDelete(req.params.id);
  if (!doc) return res.status(404).json({ message: 'Production group not found' });
  res.json({ ok: true });
});

app.get('/api/suggestions', async (_req, res) => {
  const rows = await Production.find().select('machine employee jobs').lean();
  const unique = values => [...new Map(values.filter(Boolean).map(v => [String(v).toLocaleLowerCase(), String(v)])).values()].sort((a,b) => a.localeCompare(b));
  res.json({
    machines: unique(rows.map(r => r.machine)),
    employees: unique(rows.map(r => r.employee)),
    partDescriptions: unique(rows.flatMap(r => r.jobs.map(j => j.partDescription))),
    partNumbers: unique(rows.flatMap(r => r.jobs.map(j => j.partNumber)))
  });
});

app.get('/api/export.xlsx', async (req, res) => {
  const rows = await Production.find().sort({ date: 1, machine: 1, employee: 1, shift: 1 }).lean();
  const term = clean(req.query.search).toLowerCase();
  const data = term ? rows.filter(r => [r.machine,r.employee,r.shift,...r.jobs.flatMap(j => [j.partDescription,j.partNumber,j.operation,j.otherRemark])].join(' ').toLowerCase().includes(term)) : rows;
  const wb = new ExcelJS.Workbook();
  wb.creator = 'VMC Production Tracker';
  const ws = wb.addWorksheet('Production Master', { views: [{ state: 'frozen', ySplit: 1 }] });
  ws.columns = [
    { header:'Date', key:'date', width:14 }, { header:'Machine No', key:'machine', width:16 },
    { header:'Employee Name', key:'employee', width:20 }, { header:'Shift', key:'shift', width:14 },
    { header:'Part Description', key:'partDescription', width:25 }, { header:'Part No', key:'partNumber', width:18 },
    { header:'Start Time', key:'startTime', width:14 }, { header:'End Time', key:'endTime', width:14 },
    { header:'OK Qty', key:'okQty', width:12 }, { header:'Operation', key:'operation', width:20 },
    { header:'Other Remark', key:'otherRemark', width:28 }
  ];
  const header = ws.getRow(1);
  header.height = 25;
  header.eachCell(c => { c.font = { bold:true, color:{argb:'FFFFFFFF'} }; c.fill = { type:'pattern', pattern:'solid', fgColor:{argb:'FF243447'} }; c.alignment = { horizontal:'center', vertical:'middle', wrapText:true }; });
  let rowNo = 2;
  for (const group of data) {
    const start = rowNo;
    for (const job of group.jobs) {
      const row = ws.addRow({
        date: new Date(group.date).toISOString().slice(0,10), machine:group.machine, employee:group.employee, shift:group.shift,
        partDescription:job.partDescription, partNumber:job.partNumber, startTime:job.startTime, endTime:job.endTime,
        okQty:job.okQty, operation:job.operation, otherRemark:job.otherRemark
      });
      row.height = 22;
      row.eachCell(c => { c.alignment = { horizontal:'center', vertical:'middle', wrapText:true }; c.border = { top:{style:'thin',color:{argb:'FFD1D5DB'}}, bottom:{style:'thin',color:{argb:'FFD1D5DB'}}, left:{style:'thin',color:{argb:'FFD1D5DB'}}, right:{style:'thin',color:{argb:'FFD1D5DB'}} }; });
      rowNo++;
    }
    const end = rowNo - 1;
    if (end > start) for (const col of [1,2,3,4]) ws.mergeCells(start,col,end,col);
  }
  ws.autoFilter = { from:'A1', to:'K1' };
  res.setHeader('Content-Type','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition','attachment; filename="VMC_Production_Master.xlsx"');
  await wb.xlsx.write(res);
  res.end();
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ message: 'Server error. Check server logs.' });
});

const port = Number(process.env.PORT || 4000);
await mongoose.connect(process.env.MONGODB_URI);
const username = process.env.ADMIN_USERNAME || 'admin';
const password = process.env.ADMIN_PASSWORD;
if (password && !(await Admin.findOne({ username }))) {
  const passwordHash = await bcrypt.hash(password, 12);
  await Admin.create({ username, passwordHash });
  console.log(`Created initial admin "${username}". Change its password/configuration before production use.`);
}
app.listen(port, () => console.log(`VMC API listening on ${port}`));
