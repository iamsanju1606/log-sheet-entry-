import mongoose from 'mongoose';

const jobSchema = new mongoose.Schema({
  partDescription: { type: String, required: true, trim: true },
  partNumber: { type: String, required: true, trim: true },
  startTime: { type: String, required: true },
  endTime: { type: String, required: true },
  okQty: { type: Number, required: true, min: 0 },
  operation: { type: String, trim: true, default: '' },
  otherRemark: { type: String, trim: true, default: '' }
}, { _id: true });

const productionSchema = new mongoose.Schema({
  date: { type: Date, required: true },
  machine: { type: String, required: true, trim: true },
  employee: { type: String, required: true, trim: true },
  shift: { type: String, required: true, trim: true },
  jobs: { type: [jobSchema], validate: v => v.length > 0 }
}, { timestamps: true });

productionSchema.index({ date: -1, machine: 1, employee: 1, shift: 1 });

const adminSchema = new mongoose.Schema({
  username: { type: String, unique: true, required: true },
  passwordHash: { type: String, required: true }
}, { timestamps: true });

export const Production = mongoose.model('Production', productionSchema);
export const Admin = mongoose.model('Admin', adminSchema);
